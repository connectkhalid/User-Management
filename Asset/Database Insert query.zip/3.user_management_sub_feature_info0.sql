
INSERT INTO user_management.`sub_feature_info` VALUES (1,'2025-02-04 22:57:46.000000',0,_binary '\0',1,'ADMIN_BASIC','admin basic'),(2,'2025-02-04 22:57:46.000000',0,_binary '\0',1,'USER_BASIC','user basic');
