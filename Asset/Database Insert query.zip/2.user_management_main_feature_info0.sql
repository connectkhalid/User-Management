
INSERT INTO user_management.`main_feature_info` VALUES (1,'2025-02-04 22:57:07.000000',0,_binary '\0','ACCOUNT_MANAGEMENT','account management');
